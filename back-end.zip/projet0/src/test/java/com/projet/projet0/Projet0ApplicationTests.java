package com.projet.projet0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projet0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
