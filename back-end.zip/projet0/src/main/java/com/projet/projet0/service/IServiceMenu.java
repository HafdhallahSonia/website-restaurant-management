package com.projet.projet0.service;

import java.util.List;

import com.projet.projet0.entities.Menu;

public interface IServiceMenu {
	public Menu saveMenu(Menu c);
	public Menu deleteMenu(Integer id);
	public List<Menu> getAllMenu();
	public Menu getMenu(Integer id);
	public Menu updateMenu(Menu c);
}
