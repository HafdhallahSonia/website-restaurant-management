package com.projet.projet0.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projet.projet0.entities.Crew;
import com.projet.projet0.service.IServiceCrew;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/crews")
public class CrewsController {
	@Autowired
	IServiceCrew Sc;

	// get all crews
	@GetMapping
	public List<Crew> getAll(){
		return Sc.getAllCrews();	
	}

	//create new crew
	@PostMapping
	public Crew newCrew(@RequestBody Crew c){
		return Sc.saveCrew(c);	
	}
	
	//get crew par id
	@GetMapping(path = {"/{id}"})
	public Crew getCrew(@PathVariable("id") Integer id){
		return Sc.getCrew(id);
	}

	//edit crew
	@PutMapping(path = {"/update/{id}"})
	public Crew editCrew(@RequestBody Crew c, @PathVariable("id") Integer id) {
		Crew crew = Sc.getCrew(id);
		
		crew.setAdress(c.getAdress());
		crew.setBirth(c.getBirth());
		crew.setFullname(c.getFullname());
		crew.setImage(c.getImage());
		crew.setPhone(c.getPhone());
		crew.setRole(c.getRole());
		
		return Sc.updateCrew(crew);
	}
	
	//delete crew par id
	@DeleteMapping(path = {"/{id}"})
	public Crew deleteCrew(@PathVariable("id") Integer id){
		return Sc.deleteCrew(id);
	}
	
	
}
