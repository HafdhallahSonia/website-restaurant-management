package com.projet.projet0.entities;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Reservation {

		@Id
		@GeneratedValue (strategy = GenerationType.IDENTITY)
		private Integer id;
	    private String name;
	    private String phone;
	    private String email;
	    private String date;
	    private String time;
	    private String nbPersonne;
	    
		
	    
	}


