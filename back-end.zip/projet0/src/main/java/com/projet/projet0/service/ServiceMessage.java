package com.projet.projet0.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projet.projet0.dao.MessageRepository;
import com.projet.projet0.entities.Message;


@Service
public class ServiceMessage implements IServiceMessage{
	@Autowired	
	MessageRepository mr;
	
	@Override
	public Message saveMsg(Message m) {
		// TODO Auto-generated method stub
		return mr.save(m);
	}

	@Override
	public List<Message> getAllMsg() {
		// TODO Auto-generated method stub
		return mr.findAll();	
	}

}
