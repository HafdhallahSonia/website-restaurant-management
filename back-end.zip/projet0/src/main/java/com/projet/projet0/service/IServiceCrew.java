package com.projet.projet0.service;

import java.util.List;

import com.projet.projet0.entities.Crew;

public interface IServiceCrew {
	public Crew saveCrew(Crew c);
	public Crew deleteCrew(Integer id);
	public List<Crew> getAllCrews();
	public Crew getCrew(Integer id);
	public Crew updateCrew(Crew c);
}
