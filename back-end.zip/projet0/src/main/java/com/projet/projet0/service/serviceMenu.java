package com.projet.projet0.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projet.projet0.dao.MenuRepository;
import com.projet.projet0.entities.Menu;

@Service
public class serviceMenu implements IServiceMenu{
	@Autowired	
	MenuRepository mr;

	@Override
	public  Menu saveMenu(Menu m) {
		return mr.save(m);
	}

	@Override
	public Menu deleteMenu(Integer id) {
		Menu m = mr.findById(id).get();
		if(m!=null) {
			mr.delete(m);
		}
		return m;
	}

	@Override
	public List<Menu> getAllMenu() {
		// TODO Auto-generated method stub
		return mr.findAll();
	}

	@Override
	public Menu getMenu(Integer id) {
		// TODO Auto-generated method stub
		return mr.findById(id).get();
	}


	@Override
	public Menu updateMenu(Menu m) {
		// TODO Auto-generated method stub
		return mr.save(m);
	}
}

