package com.projet.projet0.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projet.projet0.entities.Reservation;
import com.projet.projet0.service.IServiceReservation;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/reservation")
public class ReservationController {
	@Autowired
	IServiceReservation Sr;

	// get all Customer
	@GetMapping
	public List<Reservation> getAll(){
		return Sr.getAllReservation();	
	}

	//create new Customer
	@PostMapping
	public Reservation newReservation(@RequestBody Reservation c){
		return Sr.saveReservation(c);	
	}
	
	//get Customer par id
	@GetMapping(path = {"/{id}"})
	public Reservation getReservation(@PathVariable("id") Integer id){
		return Sr.getReservation(id);
	}

	//edit Customer
	@PutMapping(path = {"/update/{id}"})
	public Reservation editReservation(@RequestBody  Reservation c, @PathVariable("id") Integer id) {
		Reservation r = Sr.getReservation(id);
		r.setDate(c.getDate());
		r.setEmail(c.getEmail());
		r.setName(c.getName());
		r.setNbPersonne(c.getNbPersonne());
		r.setPhone(c.getPhone());
		r.setTime(c.getTime());
		return Sr.updateReservation(r);
	}
	
	//delete crew par id
	@DeleteMapping(path = {"/{id}"})
	public Reservation deleteReservation(@PathVariable("id") Integer id){
		return Sr.deleteReservation(id);
	}
	
	
}
