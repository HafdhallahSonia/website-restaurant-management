package com.projet.projet0.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projet.projet0.dao.ReservationRepository;
import com.projet.projet0.entities.Reservation;

@Service
public class serviceReservation implements IServiceReservation{
	@Autowired	
	ReservationRepository cr;

	@Override
	public Reservation saveReservation(Reservation c) {
		return cr.save(c);
	}

	@Override
	public Reservation deleteReservation(Integer id) {
		Reservation c = cr.findById(id).get();
		if(c!=null) {
			cr.delete(c);
		}
		return c;
	}

	@Override
	public List<Reservation> getAllReservation() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}

	@Override
	public Reservation getReservation(Integer id) {
		// TODO Auto-generated method stub
		return cr.findById(id).get();
	}
	

	@Override
	public Reservation updateReservation(Reservation c) {
		// TODO Auto-generated method stub
		return null;
	}

}
