package com.projet.projet0.entities;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Crew {

		@Id
		@GeneratedValue (strategy = GenerationType.IDENTITY)
		private Integer id;
	    private String fullname;
	    private String phone;
	    private String birth;
	    private String adress;
	    private String image;
	    private String role;
	    
	    
		
	    
	}


