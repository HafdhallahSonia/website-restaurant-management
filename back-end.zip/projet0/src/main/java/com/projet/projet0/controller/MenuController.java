package com.projet.projet0.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projet.projet0.entities.Menu;
import com.projet.projet0.service.IServiceMenu;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/menu")
public class MenuController {
	@Autowired
	IServiceMenu Sm;

	// get all menu
	@GetMapping
	public List<Menu> getAll(){
		return Sm.getAllMenu();	
	}

	//create new menu
	@PostMapping
	public Menu newCrew(@RequestBody Menu c){
		return Sm.saveMenu(c);	
	}
	
	//get menu par id
	@GetMapping(path = {"/{id}"})
	public Menu getCrew(@PathVariable("id") Integer id){
		return Sm.getMenu(id);
	}

	//edit menu
	@PutMapping(path = {"/update/{id}"})
	public Menu editCrew(@RequestBody Menu c, @PathVariable("id") Integer id) {
		Menu menu = Sm.getMenu(id);
		menu.setDescription(c.getDescription());
		menu.setImage(c.getImage());
		menu.setIngredients(c.getIngredients());
		menu.setName(c.getName());
		menu.setPrice(c.getPrice());
		menu.setType(c.getType());
		
		return Sm.updateMenu(menu);
	}
	
	//delete menu par id
	@DeleteMapping(path = {"/{id}"})
	public Menu deleteCrew(@PathVariable("id") Integer id){
		return Sm.deleteMenu(id);
	}

	

	
}
