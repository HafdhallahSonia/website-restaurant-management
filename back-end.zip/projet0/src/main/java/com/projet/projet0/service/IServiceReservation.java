package com.projet.projet0.service;

import java.util.List;

import com.projet.projet0.entities.Reservation;

public interface IServiceReservation {
	public Reservation saveReservation(Reservation c);
	public Reservation deleteReservation(Integer id);
	public List<Reservation> getAllReservation();
	public Reservation getReservation(Integer id);
	public Reservation updateReservation(Reservation c);
}
