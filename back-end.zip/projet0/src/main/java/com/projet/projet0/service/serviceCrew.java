package com.projet.projet0.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projet.projet0.dao.CrewRepository;
import com.projet.projet0.entities.Crew;

@Service
public class serviceCrew implements IServiceCrew{
@Autowired	
CrewRepository cr;

	@Override
	public Crew saveCrew(Crew c) {
		return cr.save(c);
	}

	@Override
	public Crew deleteCrew(Integer id) {
		Crew c = cr.findById(id).get();
		if(c!=null) {
			cr.delete(c);
		}
		return c;
	}

	@Override
	public List<Crew> getAllCrews() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}

	@Override
	public Crew getCrew(Integer id) {
		// TODO Auto-generated method stub
		return cr.findById(id).get();
	}

	@Override
	public Crew updateCrew(Crew c) {
		// TODO Auto-generated method stub
		return cr.save(c);
	}

}
