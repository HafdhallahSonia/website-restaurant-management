package com.projet.projet0.entities;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Menu {

		@Id
		@GeneratedValue (strategy = GenerationType.IDENTITY)
		private Integer id;
		   private String name;
		    private String type;
		    private String Ingredients;
		    private double price;
		    private String image;
		    private String description;
		
	    
	    
		
	    
	}


