package com.projet.projet0.service;

import java.util.List;

import com.projet.projet0.entities.Message;

public interface IServiceMessage {
	public Message saveMsg(Message m);
	public List<Message> getAllMsg();

}
