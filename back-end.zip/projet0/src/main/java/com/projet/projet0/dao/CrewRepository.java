package com.projet.projet0.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.projet.projet0.entities.Crew;

@Repository
public interface CrewRepository extends JpaRepository<Crew, Integer>{
	
}
