import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './element/navbar/navbar.component';
import { FooterComponent } from './element/footer/footer.component';
import { SlideComponent } from './element/slide/slide.component';
import { HomeComponent } from './pages/home/home.component';
import { MenuComponent } from './pages/menu/menu.component';
import { ReservationComponent } from './pages/reservation/reservation.component';
import { GalleryComponent } from './pages/gallery/gallery.component';
import { AboutComponent } from './pages/about/about.component';
import { ContactComponent } from './pages/contact/contact.component';
import { NavComponent } from './admin/nav/nav.component';
import { UserComponent } from './admin/user/user.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TableComponent } from './admin/table/table.component';
import { CrewComponent } from './admin/crew/crew.component';
import { ListMenuComponent } from './admin/list-menu/list-menu.component';
import { FormsModule, NgForm } from '@angular/forms';
import { ErrorComponent } from './element/error/error.component';
import { BackendCallsService } from './service/backend-calls.service';
import { SearchComponent } from './element/search/search.component';
import { IndexComponent } from './admin/index/index.component';



@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    SlideComponent,
    HomeComponent,
    MenuComponent,
    ReservationComponent,
    GalleryComponent,
    AboutComponent,
    ContactComponent,
    NavComponent,
    UserComponent,
    TableComponent,
    CrewComponent,
    ListMenuComponent,
    ErrorComponent,
    SearchComponent,
    IndexComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule, FormsModule, HttpClientModule,
  ],
  providers: [BackendCallsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
