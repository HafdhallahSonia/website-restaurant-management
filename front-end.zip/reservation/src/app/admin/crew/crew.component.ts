import { Component,  OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { Crews } from 'src/app/entities/Crews';
import { ActionService } from 'src/app/service/action.service';
import { BackendCallsService } from 'src/app/service/backend-calls.service';

@Component({
  selector: 'app-crew',
  templateUrl: './crew.component.html',
  styleUrls: ['./crew.component.css'],
})
export class CrewComponent implements OnInit{
  title='crew Settings'
  crewListe !: Crews[];
  crew = new Crews;

  constructor(private service: ActionService,
              private serviceC:BackendCallsService,
              private router: Router,  ) { }
  
  ngOnInit(): void {
    this.serviceC.getCrews().subscribe(data=>{
      this.crewListe=data;
    });
  }

//add
onSubmit(){
    this.serviceC.createCrew(this.crew).subscribe(data =>{
      console.log(data);
      this.addMsg();
      this.ngOnInit();
    })
  }

  //delete
  onDelete(crew: Crews){
    this.serviceC.deleteCrew(crew).subscribe(data =>{
      this.crewListe = this.crewListe.filter(c=>c!==crew);
      this.deleteMsg();
    } )
  }
  //get par id
  getParId(id: number){
    this.serviceC.getCrewId(id).subscribe(data =>{
      this.crew=data;
    });
  }
  //update
  onEdit(){
    this.serviceC.updatecrew(this.crew, this.crew.id).subscribe(data =>{
      this.editMsg();
      this.ngOnInit();
    })
  }

//search
searchText : string = '';

onFilterSearchInput(Value: string){
  this.searchText = Value;
}
  
// alert + fenetre
  closeResult: string | undefined;
  openWindowCustomClass(content: any) {
		this.service.openWindowCustom(content);
	}
  addMsg(){
    this.service.alertAdd();
  }
  editMsg(){
    this.service.alertUpdate();
  }
  deleteMsg(){
    this.service.alertDelete();
  }

}
