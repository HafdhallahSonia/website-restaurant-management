import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Menu } from 'src/app/entities/Menu';
import { ActionService } from 'src/app/service/action.service';
import { MenuServiceService } from 'src/app/service/menu-service.service';

@Component({
  selector: 'app-list-menu',
  templateUrl: './list-menu.component.html',
  styleUrls: ['./list-menu.component.css']
})
export class ListMenuComponent implements OnInit {
  title= 'menu Settings'
  menuListe !: Menu[];
  menu = new Menu;
  constructor(private service: ActionService,
              private serviceM:MenuServiceService,
              private router: Router,  ) { }
  
  ngOnInit(): void {
    this.serviceM.getMenu().subscribe(data=>{
      this.menuListe=data;
    });
    
  }
//add
  onSubmit(){
    this.serviceM.createMenu(this.menu).subscribe(data =>{
      console.log(data);
      this.addMsg();
      this.ngOnInit();
    } )
  }
//delete
  onDelete(menu: Menu){
    this.serviceM.deleteMenu(menu).subscribe(data =>{
      this.menuListe = this.menuListe.filter(m=>m!==menu);
      this.deleteMsg();
    } )
  }
  //get par id
  getParId(id: number){
    this.serviceM.getMenuId(id).subscribe(data =>{
      this.menu=data;
    });
  }
  //update
  onEdit(){
    this.serviceM.updateMenu(this.menu, this.menu.id).subscribe(data =>{
      this.editMsg();
      this.ngOnInit();
    })
  }
//search
  searchText : string = '';

  onFilterSearchInput(Value: string){
    this.searchText = Value;
  }
  
// alert + fenetre
  closeResult: string | undefined;
  openWindowCustomClass(content: any) {
		this.service.openWindowCustom(content);
	}
  addMsg(){
    this.service.alertAdd();
  }
  editMsg(){
    this.service.alertUpdate();
  }
  deleteMsg(){
    this.service.alertDelete();
  }

}
