import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/entities/Customer';
import { ActionService } from 'src/app/service/action.service';
import { CustomerServiceService } from 'src/app/service/customer-service.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  title='Reservation Settings';
  userListe !: Customer[];
  user = new Customer;
  constructor(private service: ActionService,
    private serviceU:CustomerServiceService,
    private router: Router, ) { }

  ngOnInit(): void {
    this.serviceU.getCustomers().subscribe(data=>{
      this.userListe=data;
    });
  }
  //add
  onSubmit(){
    this.serviceU.createCustomer(this.user).subscribe(data =>{
      console.log(data);
      this.service.alertAdd();
      this.ngOnInit();
    })
  }
//delete
  onDelete(user: Customer){
    this.serviceU.deleteCustomer(user).subscribe(data =>{
      this.userListe = this.userListe.filter(c=>c!==user);
      this.service.alertDelete();
    } )
  }
  //get par id
  getParId(id: number){
    this.serviceU.getCustomerId(id).subscribe(data =>{
      this.user=data;
    });
  }
  //update
  onEdit(){
    this.serviceU.updateCustomer(this.user, this.user.id).subscribe(data =>{
      this.service.alertUpdate();
      this.ngOnInit();
    })
  }
  
  //search
  searchText : string = '';

  onFilterSearchInput(Value: string){
    this.searchText = Value;
  }

  //action
  closeResult: string | undefined;

	openWindowCustomClass(content: any) {
		this.service.openWindowCustom(content);
	}
  


}
