import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { contact } from 'src/app/entities/contact';
import { ActionService } from 'src/app/service/action.service';
import { ContactServiceService } from 'src/app/service/contact-service.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  title='Message Settings';
  msgList !: contact[];
  msg = new contact;
  
  constructor(private service: ActionService,
    private serviceC:ContactServiceService,) { }

  ngOnInit(): void {
    this.serviceC.getMessage().subscribe(data=>{
      this.msgList=data;
    });
  }

  
  //search
  searchText : string = '';

  onFilterSearchInput(Value: string){
    this.searchText = Value;
  }

  //action
  closeResult: string | undefined;

	openWindowCustomClass(content: any) {
		this.service.openWindowCustom(content);
	}



}
