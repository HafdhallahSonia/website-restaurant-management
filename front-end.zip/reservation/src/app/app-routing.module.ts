import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CrewComponent } from './admin/crew/crew.component';
import { IndexComponent } from './admin/index/index.component';
import { ListMenuComponent } from './admin/list-menu/list-menu.component';
import { TableComponent } from './admin/table/table.component';
import { UserComponent } from './admin/user/user.component';
import { AboutComponent } from './pages/about/about.component';
import { ContactComponent } from './pages/contact/contact.component';
import { GalleryComponent } from './pages/gallery/gallery.component';
import { HomeComponent } from './pages/home/home.component';
import { MenuComponent } from './pages/menu/menu.component';
import { ReservationComponent } from './pages/reservation/reservation.component';

const routes: Routes = [
  {path:"",redirectTo:"home",pathMatch:"full"},
  {path:"home",component:HomeComponent},
  {path:"menu",component:MenuComponent},
  {path:"reservation",component:ReservationComponent},
  {path:"contact",component:ContactComponent},
  {path:"gallery",component:GalleryComponent},
  {path:"about",component:AboutComponent},
  
  {path:"admin",component:IndexComponent},
  {path:"crew",component:CrewComponent},
  {path:"reservationSettings",component:UserComponent},
  {path:"menuSettings",component:ListMenuComponent},
  {path:"messageSettings",component:TableComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
