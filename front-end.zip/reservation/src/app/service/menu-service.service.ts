import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Menu } from '../entities/Menu';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MenuServiceService {

  private baseURL  = 'http://localhost:8082/menu';

  constructor(private http: HttpClient) {
   }


//getAll
  getMenu():Observable<Menu[]>{
    return this.http.get<Menu[]>(this.baseURL);
  }
//add
  createMenu(menu: Menu):Observable<Object>{
    return this.http.post<Menu>(this.baseURL, menu);
  }
//getPId
  getMenuId(id:number):Observable<Menu>{
    return this.http.get<Menu>(this.baseURL+"/"+id);
  }
//update
  updateMenu(menu: Menu, id:number):Observable<Object>{
    return this.http.put<Menu>(`${this.baseURL}/update/${id}`, menu);
  }
//delete
   deleteMenu(menu: Menu):Observable<object>{
    return this.http.delete<Menu>(this.baseURL+"/"+menu.id);
   }


}
