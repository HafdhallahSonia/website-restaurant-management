import { Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class ActionService {

  constructor(private modalService: NgbModal) { }


  alertReg(){
    Swal.fire({
      title: 'Welcome to Gustosa.',
      width: 600,
      padding: '3em',
      color: '#716add',
      background: '#fff url(/trees.png)',
      backdrop: `
        rgba(0,0,123,0.4) 
        no-repeat
      `
    })
  }
//error
  alertError(){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      footer: "Why don't you try again!"
    })
  }
  //add
  alertAdd(){
    Swal.fire({
      icon: 'success',
      title: 'Has been saved successfully',
      showConfirmButton: false,
      timer: 1500
    })
  }
  //update
  alertUpdate(){
    Swal.fire({
      title: 'Do you want to save the changes?',
      showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: 'Save',
      denyButtonText: `Don't save`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('Saved!', '', 'success')
      } else if (result.isDenied) {
        Swal.fire('Changes are not saved', '', 'info')
      }
    })
  }
  //delete
  alertDelete(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }
  //send
  alertSend(){
    Swal.fire({
      icon: 'success',
      title: 'successfully sended',
      showConfirmButton: false,
      timer: 1500
    })
  }

  //
  openWindowCustom(content: any) {
		this.modalService.open(content, { windowClass: 'dark-modal' });
	}
  
  
}
