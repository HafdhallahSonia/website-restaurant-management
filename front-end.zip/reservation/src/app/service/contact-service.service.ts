import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { contact } from '../entities/contact';

@Injectable({
  providedIn: 'root'
})
export class ContactServiceService {
  private baseURL  = 'http://localhost:8082/contact';

  constructor(private http: HttpClient) {
   }


//getAll
  getMessage():Observable<contact[]>{
    return this.http.get<contact[]>(this.baseURL);
  }
//add
  createMesssage(user: contact):Observable<Object>{
    return this.http.post<contact>(this.baseURL, user);
  }
}