import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../entities/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
  private baseURL  = 'http://localhost:8082/reservation';

  constructor(private http: HttpClient) {
   }


//getAll
  getCustomers():Observable<Customer[]>{
    return this.http.get<Customer[]>(this.baseURL);
  }
//add
  createCustomer(user: Customer): Observable<Object>{
    return this.http.post<Customer>(this.baseURL, user);
  }
//getPId
  getCustomerId(id:number):Observable<Customer>{
    return this.http.get<Customer>(this.baseURL+"/"+id);
  }
//update
  updateCustomer(user: Customer, id:number):Observable<Object>{
    return this.http.put<Customer>(`${this.baseURL}/update/${id}`, user);
  }
//delete
   deleteCustomer(user: Customer):Observable<object>{
    return this.http.delete<Customer>(this.baseURL+"/"+user.id);
   }


}
