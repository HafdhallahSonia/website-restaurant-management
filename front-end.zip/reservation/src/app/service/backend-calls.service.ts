import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Crews } from '../entities/Crews';


@Injectable({
  providedIn: 'root'
})
export class BackendCallsService {
  private baseURL  = 'http://localhost:8082/crews';

  constructor(private http: HttpClient) {
   }


//getAll
  getCrews():Observable<Crews[]>{
    return this.http.get<Crews[]>(this.baseURL);
  }
//add
  createCrew(crew: Crews):Observable<Object>{
    return this.http.post<Crews>(this.baseURL, crew);
  }
//getPId
  getCrewId(id:number):Observable<Crews>{
    return this.http.get<Crews>(this.baseURL+"/"+id);
  }
//update
  updatecrew(crew: Crews, id:number):Observable<Object>{
    return this.http.put<Crews>(`${this.baseURL}/update/${id}`, crew);
  }
//delete
   deleteCrew(crew: Crews):Observable<object>{
    return this.http.delete<Crews>(this.baseURL+"/"+crew.id);
   }

}
