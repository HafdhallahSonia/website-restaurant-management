import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { login } from 'src/app/entities/login';
import { ActionService } from 'src/app/service/action.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  username!:string;
  password!:string;
  constructor(private modalService: NgbModal, private service: ActionService, private router: Router) { }

  ngOnInit(): void {
  }

  loginAdmin(){
    if (this.username == 'Hf.Sonia' && this.password == 'sonia2022'){ 
      this.service.alertReg();
      this.router.navigate(['admin']);
    }
    else{
      this.service.alertError();
    }
  }

  closeResult: string | undefined;

	openWindowLoginClass(contentLogin: any) {
		this.modalService.open(contentLogin, { windowClass: 'dark-modal' });
	}
  openWindowAccountlass(content: any) {
		this.modalService.open(content, { windowClass: 'dark-modal' });
	}

}
