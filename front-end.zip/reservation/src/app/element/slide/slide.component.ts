import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-slide',
  templateUrl: './slide.component.html',
  styleUrls: ['./slide.component.css']
})
export class SlideComponent implements OnInit {

  constructor(private _config:NgbCarouselConfig) { }

  ngOnInit(): void {
  }
  slide1="https://th.bing.com/th/id/R.665d792e26746a96884c121148090c10?rik=BhUZyOvCVyoGIQ&riu=http%3a%2f%2fwww.morevdesign.com%2fContent%2fUserFiles%2fGallery%2fOrjinal%2f77-IMG_4398.jpg&ehk=EIRZxPnb%2ffmIY8OMo%2b1rW226Sttnbn02ozYYcqnFgd0%3d&risl=&pid=ImgRaw&r=0";
  slide2="https://th.bing.com/th/id/R.791cd49947ad2fe0931eb7073c382fdb?rik=HJ6FqWz9CYhTcg&pid=ImgRaw&r=0"
  slide3="https://th.bing.com/th/id/R.4d63ce9fc056aa56438c71a3041f7432?rik=cW4OqK3bh2ERJQ&pid=ImgRaw&r=0&sres=1&sresct=1"

  
  title1='Welcome To Gustosa'
  title2='stay in with Gusto..'
  title3='See from our windows'
 
}
