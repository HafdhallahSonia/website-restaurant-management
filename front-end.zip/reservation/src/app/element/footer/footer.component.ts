import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  location='location'
  phone='+1234567890'
  email='GustosaRestaurant@gmail.com'
  days1='Monday - Thursday'
  days2='Friday - Sunday'
  time1='09.00 AM - 11.00 PM'
  time2='11.00 AM - 02.00 AM'
}
