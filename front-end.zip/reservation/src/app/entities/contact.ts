export class contact{
    id!: number;
    email!: string;
    phone!: string;
    message!:string;
    name!:string;
}