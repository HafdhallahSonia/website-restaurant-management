export class message{
    msg!: string;
}