export class Menu{
    id!: number;
    description!: string;
    ingredients!: string;
    image!: string;
    name!: string;
    price!: number;
    type!: string;
    
}