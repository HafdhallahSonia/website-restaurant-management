export class Customer{
    id!: number;
    email!: string;
    phone!: string;
    date!:string;
    name!:string;
    time!:string;
    nbPersonne!:string;
}