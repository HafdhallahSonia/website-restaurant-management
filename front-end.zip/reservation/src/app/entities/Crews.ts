export class Crews{
    id!:number;
    adress!:string;
    birth!:string;
    fullname!: string;
    image!:string;
    phone!:string;
    role!:string;
    

}