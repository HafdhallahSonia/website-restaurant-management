export class login{
    name!:string ;
    password!:string;
}