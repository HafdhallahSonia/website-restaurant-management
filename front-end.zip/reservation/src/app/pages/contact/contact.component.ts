import { Component, OnInit } from '@angular/core';
import { ContactServiceService } from 'src/app/service/contact-service.service';
import { contact } from 'src/app/entities/contact';
import { Router } from '@angular/router';
import { ActionService } from 'src/app/service/action.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
 img="https://www.stellaglasshardware.com/wp-content/uploads/2018/09/Chambar_Closed.jpg"
  
 msg: contact = new contact();
 constructor(private router: Router, private service: ActionService,
  private serviceC:ContactServiceService) { }

  ngOnInit(): void {
  }

  onSave(){
    this.serviceC.createMesssage(this.msg).subscribe(data =>{
      console.log(data);
      this.service.alertSend();
      
    })
  }

  onSubmit(){
    console.log(this.msg);
    this.onSave();
    this.retour();
    }

    retour(){ this.router.navigate(['/contact']);
}

}
