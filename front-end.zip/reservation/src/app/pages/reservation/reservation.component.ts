import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/entities/Customer';
import { ActionService } from 'src/app/service/action.service';
import { CustomerServiceService } from 'src/app/service/customer-service.service';

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.css']
})
export class ReservationComponent implements OnInit {
  img='https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/bv-_000.jpg'
  user : Customer = new Customer;

  constructor(private service: ActionService,
    private serviceU:CustomerServiceService,
    private router: Router,) { }

  ngOnInit(): void {
  }

    //add
    onSave(){
      this.serviceU.createCustomer(this.user).subscribe(data =>{
        console.log(data);
        this.service.alertSend();
        
      },
      error => console.log(error) );
    }
  
    onSubmit(){
      console.log(this.user);
      this.onSave();
      this.router.navigate(['/home']);
    }

}
