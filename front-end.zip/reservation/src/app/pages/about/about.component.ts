import { Component, OnInit } from '@angular/core';
import { Crews } from 'src/app/entities/Crews';
import { BackendCallsService } from 'src/app/service/backend-calls.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  crewListe !: Crews[];
  constructor(private serviceC:BackendCallsService,) { }

  ngOnInit(): void {
    this.serviceC.getCrews().subscribe(data=>{
      this.crewListe=data;
    });
  }

  slice="https://th.bing.com/th/id/R.d99915094eb6a8a77970a799a9ef2dd0?rik=aS%2b4jczW%2bAwPKg&riu=http%3a%2f%2fimg.20mn.fr%2f_ETGlUbdRDazwPNGVX18jA%2f2048x1536-fit_restaurant-new-york-24-avril-2014.jpg&ehk=3ZrfTbvSK%2fKCQpuW1CWAsqanS%2frYeyQwcZo%2bgMve6VA%3d&risl=&pid=ImgRaw&r=0"

}
