import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Menu } from 'src/app/entities/Menu';
import { MenuServiceService } from 'src/app/service/menu-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  closeResult: string | undefined;
  menuListe !: Menu[];
  slide="https://www.tijournal.fr/wp-content/uploads/2020/09/restaurant-italien-880x300.jpg"
  constructor(private modalService: NgbModal,
              private serviceM:MenuServiceService,) { }

  ngOnInit(): void {
    this.serviceM.getMenu().subscribe(data=>{
      this.menuListe=data;
    });
  }

  openFullscreen(content: any) {
		this.modalService.open(content, { fullscreen: true });
	}
}
