import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  slide1='Our Gallery'
  p1='Take a Sneak peek..'
  img1='https://th.bing.com/th/id/R.bd5e7b8f7be460850c081720671cc0a4?rik=sEH5cn5Yviy99Q&pid=ImgRaw&r=0'

  slide2=' Some exciting prose here.'
  p2='Some great content for the first featurette here.. '
  img2='https://th.bing.com/th/id/R.36dfb3d8bdeabe9c07307038a7c79938?rik=%2f59gaB3xAe6IFw&pid=ImgRaw&r=0'

  slide3='One more for good measure.'
  p3='Another one? Of course. More content here to give you an idea of some actual image of the place.'
  img3='https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/rs-gal_0000_06.09.2022-Italian-Street-Kitchen-394.jpg'


  gallery=['https://italianstreetkitchen.com/au/wp-content/uploads/2021/12/ISK_WestEnd_FamilyFriends-Low-98-1024x683.jpg',
  'https://i.pinimg.com/originals/a2/3c/ce/a23cceac01c8f076bf9845bffc22a49a.jpg',
'https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/rs-gal_0002_06.09.2022-Italian-Street-Kitchen-270.jpg',
'https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/rs-gal_0001_06.09.2022-Italian-Street-Kitchen-375.jpg',
'https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/rs-gal_0003_06.09.2022-Italian-Street-Kitchen-203.jpg']
}
