import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  title1='Always amazing experience. '
  title2='It’ll blow your mind.'
  title3='Oh yeah, it’s that good. '
  title4='See for yourself.'
  p1=''
  p2='Looking for the very best Restaurant ? At Custosa, we pride ourselves on making the most authentic food, using only the finest ingredients.'

  img3="https://th.bing.com/th/id/OIP.SNd2USNYwuPmNwNxlk8U6AHaGL?pid=ImgDet&w=672&h=560&rs=1"
  img2="https://th.bing.com/th/id/R.027123e5afd080f2863fc4d276f98ebd?rik=UPbrpwHlyyrgPA&pid=ImgRaw&r=0"
  img1='https://italianstreetkitchen.com/au/wp-content/uploads/2022/10/domcherry-5455-1-511x768.jpg'
}
